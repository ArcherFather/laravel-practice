<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>新增公告</h1>

    <form method="post" action="/msg" class="form-horizontal">
        @csrf
        公告內容 : <input id="content" name="content" type="text" placeholder="" class="form-control input-md">
        <button type="submit" id="ok" name="ok" class="btn btn-success">新增</button>
        <button type="button" class="btn btn-success" onclick="window.location.href='/';">取消</button>
    </form>
</body>
</html>
    