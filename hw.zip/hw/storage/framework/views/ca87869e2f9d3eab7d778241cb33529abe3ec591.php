<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>編輯公告</h1>

    <form method="post" action="/msg/<?php echo e($msg->id); ?>" class="form-horizontal">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input type="hidden" id="id" name="id" value="<?php echo e($msg->id); ?>">
        公告內容 : <input id="content" name="content" type="text" placeholder="" class="form-control input-md" value="<?php echo e($msg->content); ?>">
        <button type="submit" id="ok" name="ok" class="btn btn-success">修改</button>
        <button type="button" class="btn btn-success" onclick="window.location.href='/';">取消</button>
    </form>
</body>
</html>
    <?php /**PATH C:\Lab\hw\resources\views/msg/edit.blade.php ENDPATH**/ ?>