<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<div class="container">
    <h1>公告系統</h1><hr>

    <fieldset>
    
    <!-- Form Name -->
    <legend>
        公告區
        <a href="/msg/create" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> 新增公告</a>
    </legend>
        <?php $__currentLoopData = $msgList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form method="post" action="/msg/<?php echo e($msg->id); ?>" onSubmit="if(!confirm('確定要刪除此公告?')){return false;}">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <a href="/msg/<?php echo e($msg->id); ?>/edit" class="btn btn-success btn-xs"><i class="fas fa-edit"></i> 編輯</a>
                <button type="submit" class="btn btn-danger btn-xs"><i class="fas fa-trash"></i> 刪除</button>
                <b>公告 : <?php echo e($msg->content); ?></b> <hr>
            </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </fieldset>
</div>
</body>
</html>
    <?php /**PATH C:\Lab\hw\resources\views/home/index.blade.php ENDPATH**/ ?>