<?php $__env->startSection('head'); ?>
    <style>
        .fail {
            color: red;
        }
    </style>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Home Index</h1>
    <p>Hello! <?php echo e($userName); ?></p>
    <div><?php echo $lines; ?></div>
    <ul>
    <?php $__currentLoopData = $scoreList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="<?php echo e(($score < 60) ? 'fail' : ''); ?>">
            <?php echo e($score); ?>

        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <select name="city" id="city">
        <option value="2" <?php echo e(($cityId == 2) ? 'selected' : ''); ?>>台北</option>
        <option value="4" <?php echo e(($cityId == 4) ? 'selected' : ''); ?>>台中</option>
        <option value="6" <?php echo e(($cityId == 6) ? 'selected' : ''); ?>>台南</option>
    </select>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Lab\view\resources\views/home/index.blade.php ENDPATH**/ ?>