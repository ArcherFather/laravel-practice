@extends('layout.master')

@section('content')
    <h1>Page 2</h1>
@endsection