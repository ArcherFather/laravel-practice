@extends('layout.master')

@section('content')
    <h1>Page 3</h1>
@endsection