<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    function index(Request $request){
        $userName = $request->session()->get("userName", "guest");
        return view("home.index", compact("userName"));
    }

    function member(Request $request){
        $userName = $request->session()->get("userName", "guest");
        if($userName == "guest"){
            return redirect("/member/login");
        }
        return view("home.member");
    }
}
