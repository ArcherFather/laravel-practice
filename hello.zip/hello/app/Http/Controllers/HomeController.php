<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    function index(){
        return view('home.index');
    }

    function about(){
        return "about test";
    }

    function sayHello(Request $request) {
        // dd($request);
        // dd($request->input("userName"));
        // dd($request->userName);

        // 輸出至前端的方法
        // (1)
        // return view("home.hello")->withWho($request->userName);
        // (2)
        $who = $request->userName;
        return view("home.hello", compact("who"));
        // (3)
        // return view("home.hello", ['who' => $request->userName]);
    }
}
